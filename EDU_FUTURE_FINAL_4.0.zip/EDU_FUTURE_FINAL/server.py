from collections import defaultdict, deque
from pathlib import Path
import json, os, time
import httpx
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel, Field

ROOT = Path(__file__).resolve().parent
load_dotenv(ROOT / ".env")
app = FastAPI(title="EDU FUTURE", version="4.0")
limits = defaultdict(deque)

class AIRequest(BaseModel):
    message: str = Field(min_length=1, max_length=3000)
    grade: int = Field(ge=1, le=12)
    subject: str = Field(min_length=1, max_length=120)

@app.get("/")
def index():
    return FileResponse(ROOT / "index.html")

@app.get("/api/health")
def health():
    return {"status": "ok", "ai_configured": bool(os.getenv("OPENROUTER_API_KEY"))}

@app.get("/api/curriculum")
def curriculum():
    p = ROOT / "curriculum_2026_2027.json"
    return json.loads(p.read_text(encoding="utf-8"))

@app.post("/api/ai")
async def ask_ai(data: AIRequest, request: Request):
    ip = request.client.host if request.client else "unknown"
    now = time.time()
    q = limits[ip]
    while q and now - q[0] > 60:
        q.popleft()
    if len(q) >= 8:
        raise HTTPException(429, "Изпратени са твърде много въпроси за кратко време. Опитай след минута.")
    q.append(now)

    key = os.getenv("OPENROUTER_API_KEY")
    if not key:
        raise HTTPException(503, "EDU AI още не е активиран от администратора.")
    model = os.getenv("OPENROUTER_MODEL", "openrouter/free")
    payload = {
        "model": model,
        "messages": [
            {
                "role": "system",
                "content": (
                    "Ти си EDU AI — образователен помощник за ученици в България. "
                    "Отговаряй на български и съобразявай обясненията с класа и предмета. "
                    "Обяснявай стъпка по стъпка, използвай кратки примери и насърчавай ученика да мисли. "
                    "Не твърди, че даден урок е от конкретен учебник, ако съдържанието не е предоставено. "
                    "Не измисляй факти, програми или заглавия. Когато не си сигурен, кажи го. "
                    "Не искай лични данни и не съхранявай лична информация."
                )
            },
            {
                "role": "user",
                "content": f"Клас: {data.grade}. Предмет: {data.subject}. Въпрос: {data.message}"
            }
        ],
        "temperature": 0.35
    }
    try:
        async with httpx.AsyncClient(timeout=45) as client:
            response = await client.post(
                "https://openrouter.ai/api/v1/chat/completions",
                headers={
                    "Authorization": f"Bearer {key}",
                    "Content-Type": "application/json",
                    "X-Title": "EDU FUTURE"
                },
                json=payload
            )
        if response.status_code == 429:
            raise HTTPException(429, "Безплатната AI квота е достигната. Опитай по-късно.")
        response.raise_for_status()
        data_out = response.json()
        answer = data_out["choices"][0]["message"]["content"]
        return {"answer": answer}
    except HTTPException:
        raise
    except Exception:
        raise HTTPException(502, "AI услугата временно не отговори. Опитай отново по-късно.")
